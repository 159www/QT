/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLineEdit *lineEdit;
    QGroupBox *groupBox;
    QPushButton *pushButton_clear;
    QPushButton *pushButton6;
    QPushButton *pushButton_multi;
    QPushButton *pushButton5;
    QPushButton *pushButton_point;
    QPushButton *pushButton_div;
    QPushButton *pushButton4;
    QPushButton *pushButton9;
    QPushButton *pushButton_equal;
    QPushButton *pushButton_minus;
    QPushButton *pushButton1;
    QPushButton *pushButton2;
    QPushButton *pushButton_add;
    QPushButton *pushButton0;
    QPushButton *pushButton_back;
    QPushButton *pushButton8;
    QPushButton *pushButton7;
    QPushButton *pushButton3;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(770, 600);
        lineEdit = new QLineEdit(Widget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(80, 20, 581, 81));
        groupBox = new QGroupBox(Widget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(40, 120, 671, 381));
        pushButton_clear = new QPushButton(groupBox);
        pushButton_clear->setObjectName(QString::fromUtf8("pushButton_clear"));
        pushButton_clear->setGeometry(QRect(560, 90, 81, 61));
        pushButton6 = new QPushButton(groupBox);
        pushButton6->setObjectName(QString::fromUtf8("pushButton6"));
        pushButton6->setGeometry(QRect(20, 190, 81, 61));
        pushButton_multi = new QPushButton(groupBox);
        pushButton_multi->setObjectName(QString::fromUtf8("pushButton_multi"));
        pushButton_multi->setGeometry(QRect(430, 190, 81, 61));
        pushButton5 = new QPushButton(groupBox);
        pushButton5->setObjectName(QString::fromUtf8("pushButton5"));
        pushButton5->setGeometry(QRect(300, 100, 81, 61));
        pushButton_point = new QPushButton(groupBox);
        pushButton_point->setObjectName(QString::fromUtf8("pushButton_point"));
        pushButton_point->setGeometry(QRect(160, 290, 81, 61));
        pushButton_div = new QPushButton(groupBox);
        pushButton_div->setObjectName(QString::fromUtf8("pushButton_div"));
        pushButton_div->setGeometry(QRect(430, 290, 81, 61));
        pushButton4 = new QPushButton(groupBox);
        pushButton4->setObjectName(QString::fromUtf8("pushButton4"));
        pushButton4->setGeometry(QRect(160, 100, 81, 61));
        pushButton9 = new QPushButton(groupBox);
        pushButton9->setObjectName(QString::fromUtf8("pushButton9"));
        pushButton9->setGeometry(QRect(20, 290, 81, 61));
        pushButton_equal = new QPushButton(groupBox);
        pushButton_equal->setObjectName(QString::fromUtf8("pushButton_equal"));
        pushButton_equal->setGeometry(QRect(300, 290, 81, 61));
        pushButton_minus = new QPushButton(groupBox);
        pushButton_minus->setObjectName(QString::fromUtf8("pushButton_minus"));
        pushButton_minus->setGeometry(QRect(430, 100, 81, 61));
        pushButton1 = new QPushButton(groupBox);
        pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
        pushButton1->setGeometry(QRect(160, 20, 81, 61));
        pushButton2 = new QPushButton(groupBox);
        pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
        pushButton2->setGeometry(QRect(300, 20, 81, 61));
        pushButton_add = new QPushButton(groupBox);
        pushButton_add->setObjectName(QString::fromUtf8("pushButton_add"));
        pushButton_add->setGeometry(QRect(430, 20, 81, 61));
        pushButton0 = new QPushButton(groupBox);
        pushButton0->setObjectName(QString::fromUtf8("pushButton0"));
        pushButton0->setGeometry(QRect(20, 20, 81, 61));
        pushButton0->setAutoFillBackground(false);
        pushButton_back = new QPushButton(groupBox);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));
        pushButton_back->setGeometry(QRect(560, 20, 81, 61));
        pushButton8 = new QPushButton(groupBox);
        pushButton8->setObjectName(QString::fromUtf8("pushButton8"));
        pushButton8->setGeometry(QRect(300, 190, 81, 61));
        pushButton7 = new QPushButton(groupBox);
        pushButton7->setObjectName(QString::fromUtf8("pushButton7"));
        pushButton7->setGeometry(QRect(160, 190, 81, 61));
        pushButton3 = new QPushButton(groupBox);
        pushButton3->setObjectName(QString::fromUtf8("pushButton3"));
        pushButton3->setGeometry(QRect(20, 100, 81, 61));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        groupBox->setTitle(QString());
        pushButton_clear->setText(QApplication::translate("Widget", "\346\270\205\351\231\244", nullptr));
        pushButton6->setText(QApplication::translate("Widget", "6", nullptr));
        pushButton_multi->setText(QApplication::translate("Widget", "*", nullptr));
        pushButton5->setText(QApplication::translate("Widget", "5", nullptr));
        pushButton_point->setText(QApplication::translate("Widget", ".", nullptr));
        pushButton_div->setText(QApplication::translate("Widget", "/", nullptr));
        pushButton4->setText(QApplication::translate("Widget", "4", nullptr));
        pushButton9->setText(QApplication::translate("Widget", "9", nullptr));
        pushButton_equal->setText(QApplication::translate("Widget", "=", nullptr));
        pushButton_minus->setText(QApplication::translate("Widget", "-", nullptr));
        pushButton1->setText(QApplication::translate("Widget", "1", nullptr));
        pushButton2->setText(QApplication::translate("Widget", "2", nullptr));
        pushButton_add->setText(QApplication::translate("Widget", "+", nullptr));
        pushButton0->setText(QApplication::translate("Widget", "0", nullptr));
        pushButton_back->setText(QApplication::translate("Widget", "\351\200\200\346\240\274", nullptr));
        pushButton8->setText(QApplication::translate("Widget", "8", nullptr));
        pushButton7->setText(QApplication::translate("Widget", "7", nullptr));
        pushButton3->setText(QApplication::translate("Widget", "3", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
