#include "Calculator.h"

Calculator::Calculator(QString lamda):lamda(lamda)
{

}
QString Calculator::Calculate()
{
    QString temp=NULL;
    QString result=NULL;
    int index_numbers=0;//用于将操作数按位置放入数组
    int index_calculate_symbols=0;//用于将操作符按位置放入数组
    //运算符数量
    int calculate_symbol_count=(this->lamda.count('+')+this->lamda.count('-')+this->lamda.count('*')+this->lamda.count('/'));
    //操作数数量
    int numbers_count=calculate_symbol_count+1;
    //存放操作数的字符串数组
    QString numbers[numbers_count];
    //存放运算符的字符串数组
    QString calculate_symbols[calculate_symbol_count];
    //QString  lamda[this->lamda.length()];
    //1、解析表达式并把操作数和操作符分别放置到不同字符串数组

    //1.1 获取操作数和操作符的数量并创建对应的字符串数组
    for(int i=0;i<this->lamda.length();i++)//不遍历到等号
    {
        if(this->lamda.at(i)!='+'&&this->lamda.at(i)!='-'&&this->lamda.at(i)!='*'&&this->lamda.at(i)!='/'&&this->lamda.at(i)!='=')
        {
            temp+=this->lamda.at(i);
        }
        else if(this->lamda.at(i)=='+')
        {
            numbers[index_numbers]=temp;
            index_numbers++;
            temp.clear();
            temp=this->lamda.at(i);
            calculate_symbols[index_calculate_symbols]=temp;
            index_calculate_symbols++;
            temp.clear();
        }
        else if(this->lamda.at(i)=='-')
        {
            numbers[index_numbers]=temp;
            index_numbers++;
            temp.clear();
            temp=this->lamda.at(i);
            calculate_symbols[index_calculate_symbols]=temp;
            index_calculate_symbols++;
            temp.clear();
        }
        else if(this->lamda.at(i)=='/')
        {
            numbers[index_numbers]=temp;
            index_numbers++;
            temp.clear();
            temp=this->lamda.at(i);
            calculate_symbols[index_calculate_symbols]=temp;
            index_calculate_symbols++;
            temp.clear();
        }
        else if(this->lamda.at(i)=='*')
        {
            numbers[index_numbers]=temp;
            index_numbers++;
            temp.clear();
            temp=this->lamda.at(i);
            calculate_symbols[index_calculate_symbols]=temp;
            index_calculate_symbols++;
            temp.clear();
        }
        else if(this->lamda.at(i)=='=')
        {
            numbers[index_numbers]=temp;
            index_numbers++;
            temp.clear();

        }



     }
    index_numbers=0;
    index_calculate_symbols=0;
    //2、计算
    for(int i=0;i<calculate_symbol_count;i++)
    {
        if(calculate_symbols[i]=='+')
        {
            numbers[i+1]=QString::number(  ((numbers[i].toDouble())+(numbers[i+1].toDouble())  ),'f',9);
        }
        else if(calculate_symbols[i]=='-')
        {
            numbers[i+1]=QString::number(  ((numbers[i].toDouble())-(numbers[i+1].toDouble())  ),'f',9);
        }
        else if(calculate_symbols[i]=='*')
        {
             numbers[i+1]=QString::number(  ((numbers[i].toDouble())*(numbers[i+1].toDouble())  ),'f',9);
        }
        else if(calculate_symbols[i]=='/')
        {
             numbers[i+1]=QString::number(  ((numbers[i].toDouble())/(numbers[i+1].toDouble())  ),'f',9);
        }
    }


    result=numbers[numbers_count-1];

    this->lamda.clear();
    return result;
}
