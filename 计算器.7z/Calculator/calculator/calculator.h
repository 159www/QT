#ifndef CALCULATOR_H
#define CALCULATOR_H
#include<QString>


class Calculator
{
private:
    QString lamda=NULL;
public:
    Calculator(QString lamda);//构造函数传入要计算的表达式
    QString Calculate();//计算算数表达式并返回结果字符出串
};

#endif // CALCULATOR_H
