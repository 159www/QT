#include "widget.h"
#include "ui_widget.h"
#include<QString>
#include<QFont>
#include<QMessageBox>
#include<QDebug>
#include"Calculator.h"
QString  lamda;
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->lineEdit->setFont( QFont("bold",40,20));//设置lineedit字体大小
    this->setWindowTitle("Calculator");
    this->setAutoFillBackground(true);
    QPalette p=this->palette();
    QFont  f=this->font();
    p.setColor(QPalette::Background,Qt::red);    p.setColor(QPalette::Button,Qt::Key_Red);
    f.setPointSize(20);
    f.setBold(true);
  // this->setPalette(p);
    this->setFont(f);
    this->setMaximumSize(770,600);





}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButton0_clicked()
{
    lamda+="0";
    ui->lineEdit->setText(lamda);


}

void Widget::on_pushButton1_clicked()
{
    lamda+="1";
     ui->lineEdit->setText(lamda);
}



void Widget::on_pushButton2_clicked()
{
    lamda+="2";
    ui->lineEdit->setText(lamda);
}

void Widget::on_pushButton3_clicked()
{
    lamda+="3";
    ui->lineEdit->setText(lamda);
}

void Widget::on_pushButton4_clicked()
{
    lamda+="4";
    ui->lineEdit->setText(lamda);

}

void Widget::on_pushButton5_clicked()
{
    lamda+="5";
    ui->lineEdit->setText(lamda);
}

void Widget::on_pushButton6_clicked()
{
    lamda+="6";
    ui->lineEdit->setText(lamda);
}

void Widget::on_pushButton7_clicked()
{
    lamda+="7";
    ui->lineEdit->setText(lamda);
}

void Widget::on_pushButton8_clicked()
{
    lamda+="8";
    ui->lineEdit->setText(lamda);
}

void Widget::on_pushButton9_clicked()
{
    lamda+="9";
    ui->lineEdit->setText(lamda);
}

void Widget::on_pushButton_point_clicked()
{
    if(lamda.size()>=1)
    {
        if(lamda.at(lamda.toLocal8Bit().length()-1)=='.')
        {
            QMessageBox::information(this,"warming","请先输入操作数");
        }
        else
        {
            lamda+=".";
            ui->lineEdit->setText(lamda);
        }

    }
    else if(lamda.size()==0)
    {
        QMessageBox::information(this,"warming","请先输入操作数");
    }

}

void Widget::on_pushButton_equal_clicked()
{
    if(lamda.contains("="))
    {
        QMessageBox::information(this,"warming","不能存在两个即以上的等号");
    }
    else if(lamda==NULL)
    {
         QMessageBox::information(this,"warming","请先输入操作数");
   }
    else
    {

        lamda+="=";
        Calculator calculator(lamda);
        ui->lineEdit->setText(lamda);
        QString  result=calculator.Calculate();
        lamda+=result;
        ui->lineEdit->clear();
        ui->lineEdit->setText(lamda);
        lamda.clear();
        //1、提取表达式

        //2、进行运算

        //3、显示
    }

}

void Widget::on_pushButton_add_clicked()
{
    if(lamda.size()>=1)
    {
        if(lamda.at(lamda.toLocal8Bit().length()-1)=='+'||lamda.at(lamda.toLocal8Bit().length()-1)=='-'||lamda.at(lamda.toLocal8Bit().length()-1)=='*'||lamda.at(lamda.toLocal8Bit().length()-1)=='\\')
        {
            QMessageBox::information(this,"warming","请先输入操作数");
        }
        else
        {
            lamda+="+";
            ui->lineEdit->setText(lamda);
        }

    }
    else if(lamda.size()==0)
    {
        QMessageBox::information(this,"warming","请先输入操作数");
    }


}

void Widget::on_pushButton_minus_clicked()
{
    if(lamda.size()>=1)
    {
        if(lamda.at(lamda.toLocal8Bit().length()-1)=='+'||lamda.at(lamda.toLocal8Bit().length()-1)=='-'||lamda.at(lamda.toLocal8Bit().length()-1)=='*'||lamda.at(lamda.toLocal8Bit().length()-1)=='\\')
        {
            QMessageBox::information(this,"warming","请先输入操作数");
        }
        else
        {
            lamda+="-";
            ui->lineEdit->setText(lamda);
        }

    }
    else if(lamda.size()==0)
    {
        QMessageBox::information(this,"warming","请先输入操作数");
    }
}

void Widget::on_pushButton_multi_clicked()
{
    if(lamda.size()>=1)
    {
        if(lamda.at(lamda.toLocal8Bit().length()-1)=='+'||lamda.at(lamda.toLocal8Bit().length()-1)=='-'||lamda.at(lamda.toLocal8Bit().length()-1)=='*'||lamda.at(lamda.toLocal8Bit().length()-1)=='\\')
        {
            QMessageBox::information(this,"warming","请先输入操作数");
        }
        else
        {
            lamda+="*";
            ui->lineEdit->setText(lamda);
        }

    }
    else if(lamda.size()==0)
    {
        QMessageBox::information(this,"warming","请先输入操作数");
    }
}

void Widget::on_pushButton_div_clicked()
{
    if(lamda.size()>=1)
    {
        if(lamda.at(lamda.toLocal8Bit().length()-1)=='+'||lamda.at(lamda.toLocal8Bit().length()-1)=='-'||lamda.at(lamda.toLocal8Bit().length()-1)=='*'||lamda.at(lamda.toLocal8Bit().length()-1)=='\\')
        {
            QMessageBox::information(this,"warming","请先输入操作数");
        }
        else
        {
            lamda+="/";
            ui->lineEdit->setText(lamda);
        }

    }
    else if(lamda.size()==0)
    {
        QMessageBox::information(this,"warming","请先输入操作数");
    }
}

void Widget::on_pushButton_clear_clicked()
{
    ui->lineEdit->clear();
}

void Widget::on_pushButton_back_clicked()//退格
{
    lamda.remove(lamda.length()-1,1);
    ui->lineEdit->clear();
    ui->lineEdit->setText(lamda);
}
